import streamlit as st
from datetime import datetime
import csv
from pathlib import Path
import uuid
import json
import streamlit.components.v1 as components  # ✅ 복사 버튼용
from PIL import Image  # ✅ 아바타용

# ============================================================================
# 페이지 설정 (가장 먼저!)
# ============================================================================
st.set_page_config(
    page_title="홍익대 RAG QnA 챗봇 (프론트 전용)",
    page_icon="💬",
    layout="wide"
)

# ============================================================================
# 전역 설정
# ============================================================================

# 세션 히스토리 저장소 (백엔드용이 아니라, 여기서는 예시로만 사용)
STORE = {}

# ✅ assistant(챗봇) 아바타: 홍익대 로고
try:
    HONGIK_AVATAR = Image.open("hongik_emblem.png")
except Exception:
    HONGIK_AVATAR = "🤖"

# ✅ user(질문자) 아바타: mascot.png
try:
    USER_AVATAR = Image.open("mascot.png")
except Exception:
    USER_AVATAR = "👤"

# ============================================================================
# 세션 상태 초기화
# ============================================================================
if "messages" not in st.session_state:
    st.session_state.messages = []

if "feedback_mode" not in st.session_state:
    st.session_state.feedback_mode = {}

if "feedback_ids" not in st.session_state:
    st.session_state.feedback_ids = {}

if "pending_question" not in st.session_state:
    st.session_state.pending_question = None

if "session_id" not in st.session_state:
    st.session_state.session_id = str(uuid.uuid4())

if "selected_category" not in st.session_state:
    st.session_state.selected_category = "전체"

# ============================================================================
# 카테고리 설정
# ============================================================================
CATEGORIES = {
    "전체": None,  # 필터 없음
    "학교 공지": ["학교 공지"],
    "학과 공지": ["학과 공지"],
    "개설 과목": ["개설 과목"]
}

# ============================================================================
# 빠른 질문
# ============================================================================
QUICK_QUESTIONS = {
    "전체": [
        "최근 공지사항 알려줘",
        "이번 학기 주요 일정은?",
        "장학금 정보 알려줘"
    ],
    "학교 공지": [
        "학교 전체 공지사항 최근거 보여줘",
        "대학원 입학 정보 알려줘",
        "학사 일정 알려줘"
    ],
    "학과 공지": [
        "디자인학부 공지사항 알려줘",
        "건축학부 최근 소식은?",
        "컴퓨터공학부 공지 보여줘"
    ],
    "개설 과목": [
        "이번 학기 개설 과목 알려줘",
        "수강신청 일정은?",
        "교양 과목 추천해줘"
    ]
}

# ============================================================================
# 유틸 함수들 (백엔드 없이도 동작)
# ============================================================================


def save_feedback(feedback_data, is_update=False, feedback_id=None):
    """피드백을 CSV 파일로 저장"""
    feedback_dir = Path("data/feedbacks")
    feedback_dir.mkdir(parents=True, exist_ok=True)

    today = datetime.now().strftime("%Y%m%d")
    feedback_file = feedback_dir / f"feedback_{today}.csv"

    fieldnames = [
        "feedback_id", "timestamp", "question", "answer",
        "feedback_type", "feedback_text", "edit_count", "updated_at"
    ]

    if is_update and feedback_id:
        feedbacks = []
        if feedback_file.exists():
            with open(feedback_file, "r", encoding="utf-8", newline="") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if row.get("feedback_id") == feedback_id:
                        row["feedback_text"] = feedback_data["feedback_text"]
                        row["updated_at"] = datetime.now().isoformat()
                        row["edit_count"] = str(int(row.get("edit_count", 0)) + 1)
                    feedbacks.append(row)

        with open(feedback_file, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(feedbacks)
    else:
        feedback_data["feedback_id"] = f"{feedback_data['timestamp']}_{id(feedback_data)}"
        feedback_data["edit_count"] = 0
        feedback_data["updated_at"] = ""

        file_exists = feedback_file.exists()
        with open(feedback_file, "a", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            if not file_exists:
                writer.writeheader()
            writer.writerow(feedback_data)


def render_copy_button(content: str, idx: int):
    """
    각 답변 옆에 붙는 '복사' 버튼.
    - 모양은 작은 '복사' 버튼 그대로
    - JS로 실제 클립보드 복사 수행
    """
    js_text = json.dumps(content)

    copy_html = f"""
    <html>
    <body>
      <button onclick="copyText_{idx}()"
              style="font-size:0.7rem;padding:3px 10px;
                     border-radius:6px;border:1px solid #ccc;
                     background:#fff;cursor:pointer;">
        복사
      </button>

      <script>
        const textToCopy_{idx} = {js_text};

        function copyText_{idx}() {{
            if (navigator.clipboard && navigator.clipboard.writeText) {{
                navigator.clipboard.writeText(textToCopy_{idx}).then(() => {{
                    alert("복사되었습니다");
                }}).catch(err => {{
                    fallbackCopy_{idx}();
                }});
            }} else {{
                fallbackCopy_{idx}();
            }}
        }}

        function fallbackCopy_{idx}() {{
            const ta = document.createElement("textarea");
            ta.value = textToCopy_{idx};
            document.body.appendChild(ta);
            ta.select();
            document.execCommand("copy");
            document.body.removeChild(ta);
            alert("복사되었습니다");
        }}
      </script>
    </body>
    </html>
    """

    # 버튼 안 잘리도록 적당한 크기
    components.html(copy_html, height=60, width=120)


def render_sources_box(sources: list):
    """
    assistant 메시지 아래에 '출처' 박스 렌더링
    """
    if not sources:
        return

    src_html = """
    <div style="
        font-size:0.75rem;
        color:#555;
        margin-top:0.35rem;
        margin-bottom:0.4rem;
        padding:0.4rem 0.6rem;
        background-color:#f5f6fa;
        border-radius:6px;
        border:1px solid #e0e3ec;
    ">
      <div style="font-weight:600; margin-bottom:0.2rem;">출처</div>
    """
    for s in sources:
        src_html += f"· {s}<br>"
    src_html += "</div>"

    st.markdown(src_html, unsafe_allow_html=True)


def get_confidence_level(similarity: float) -> tuple:
    """
    유사도 점수를 기반으로 신뢰도 레벨 반환.
    👉 현재 버전은 실제 유사도 계산이 없기 때문에,
       나중에 백엔드에서 similarity 값을 넘겨줄 때 사용하면 됨.
    """
    if similarity >= 0.8:
        return "매우 높음 ⭐⭐⭐", "🟢", "success"
    elif similarity >= 0.6:
        return "높음 ⭐⭐", "🟡", "info"
    elif similarity >= 0.4:
        return "보통 ⭐", "🟠", "warning"
    else:
        return "낮음", "🔴", "error"


def display_confidence_badge(similarity: float):
    """신뢰도 배지 표시 (현재는 similarity가 없으니 사용 안 됨)"""
    confidence_text, emoji, alert_type = get_confidence_level(similarity)

    if alert_type == "success":
        st.success(f"{emoji} **답변 신뢰도: {confidence_text}** ({similarity:.1%})")
    elif alert_type == "info":
        st.info(f"{emoji} **답변 신뢰도: {confidence_text}** ({similarity:.1%})")
    elif alert_type == "warning":
        st.warning(f"{emoji} **답변 신뢰도: {confidence_text}** ({similarity:.1%})")
    else:
        st.error(f"{emoji} **답변 신뢰도: {confidence_text}** ({similarity:.1%})")
        st.caption("💡 검색 결과와 질문의 유사도가 낮습니다. 질문을 더 구체적으로 해보세요.")


def process_question(prompt: str):
    """
    질문 처리 및 응답 생성 (현재는 더미/예시 응답만 생성)
    👉 나중에 여기에서 LangChain / RAG / 자체 API를 호출해서
       실제 응답을 받아오면 됨.
    """
    # 사용자 메시지 저장
    st.session_state.messages.append({"role": "user", "content": prompt})

    try:
        # 예시 더미 응답
        response = (
            "🤖 (예시 응답)\n\n"
            "질문을 잘 받았습니다.\n"
            "현재는 RAG/LLM 백엔드가 연결되어 있지 않아, "
            "임시 안내 메시지만 표시하고 있습니다.\n\n"
            "➡️ 나중에 이 부분에서 실제 모델 응답을 받아오면 됩니다."
        )

        # 나중에 실제 RAG 연동 시, 여기서 검색된 문서 출처 리스트 넣으면 됨
        sources = [
            "홍익대학교 공식 홈페이지",
            "학사공지 / 학사일정 페이지",
        ]

        # similarity는 아직 없으므로 None으로 설정
        similarity_score = None

        # 어시스턴트 메시지 저장 (출처 포함)
        st.session_state.messages.append({
            "role": "assistant",
            "content": response,
            "similarity": similarity_score,
            "sources": sources,
        })

    except Exception as e:
        error_message = f"죄송합니다. 오류가 발생했습니다: {str(e)}"
        st.session_state.messages.append({
            "role": "assistant",
            "content": error_message,
            "similarity": None,
            "sources": [],
        })

# ============================================================================
# UI 렌더링
# ============================================================================

# 타이틀
st.title("💬 홍익대 QnA 챗봇 (프론트 전용)")
st.markdown("---")

# 사이드바
with st.sidebar:
    st.header("⚙️ 설정")

    # (예시) 백엔드 연결 상태 표시 자리
    st.info("🖥️ 현재는 백엔드가 연결되지 않은 프론트엔드 전용 버전입니다.")
    st.caption("나중에 RAG/LLM 서버 상태를 여기서 보여줄 수 있습니다.")

    st.markdown("---")

    # 카테고리 필터
    st.subheader("🏷️ 카테고리 필터")
    selected_category = st.radio(
        "검색 범위 선택:",
        options=list(CATEGORIES.keys()),
        index=0,
        key="category_radio"
    )

    # 카테고리 변경 시 세션에 저장
    if st.session_state.selected_category != selected_category:
        st.session_state.selected_category = selected_category
        st.info(f"📌 '{selected_category}' 카테고리가 선택되었습니다")

    # 선택된 카테고리 설명
    if selected_category == "전체":
        st.caption("💡 모든 카테고리에서 검색합니다")
    elif selected_category == "학교 공지":
        st.caption("💡 학교 전체 공지사항을 검색합니다")
    elif selected_category == "학과 공지":
        st.caption("💡 각 학과별 공지사항을 검색합니다")
    elif selected_category == "개설 과목":
        st.caption("💡 수강신청 및 강의 관련 정보를 검색합니다")

    st.markdown("---")

    # 대화 초기화 버튼
    if st.button("🔄 대화 초기화", use_container_width=True):
        st.session_state.messages = []
        st.session_state.feedback_mode = {}
        st.session_state.feedback_ids = {}
        st.session_state.pending_question = None
        st.rerun()

    st.markdown("---")

    # 빠른 질문 버튼
    st.subheader("⚡ 빠른 질문")

    # 선택된 카테고리에 맞는 질문 표시
    category_questions = QUICK_QUESTIONS.get(
        st.session_state.selected_category, QUICK_QUESTIONS["전체"]
    )

    for question in category_questions:
        if st.button(f"💭 {question}", use_container_width=True):
            st.session_state.pending_question = question
            st.rerun()

    st.markdown("---")

    # 시스템 정보
    st.caption("📁 시스템 정보")
    st.caption(f"세션 ID: {st.session_state.session_id[:8]}...")

    feedback_dir = Path("data/feedbacks")
    if feedback_dir.exists():
        feedback_files = list(feedback_dir.glob("*.csv"))
        st.caption(f"📊 피드백: {len(feedback_files)}개 파일")
    else:
        st.caption("📝 피드백 없음")

# ✅ 초기 안내 메시지: 항상 상단에 고정 표시
st.info(f"""
👋 **안녕하세요! 홍익대학교 학사 정보 안내 챗봇 (프론트 전용 버전)입니다.**

현재 선택된 카테고리: **{st.session_state.selected_category}**

이 버전은 **UI/UX와 피드백 기능만 구현**되어 있으며,
실제 답변 생성은 아직 백엔드와 연결되지 않았습니다.

📌 **카테고리별 검색 (UI만 동작):**
- **전체**: 모든 정보 검색
- **학교 공지**: 학교 전체 공지사항
- **학과 공지**: 각 학과별 공지사항  
- **개설 과목**: 수강신청 및 강의 정보

💡 나중에 LangChain / RAG / OpenAI API 등을 연동하면
이 UI 그대로 사용할 수 있습니다!
""")

# 빠른 질문 처리
if st.session_state.pending_question:
    process_question(st.session_state.pending_question)
    st.session_state.pending_question = None
    st.rerun()

# 대화 내역 표시
for idx, message in enumerate(st.session_state.messages):
    role = message["role"]

    # ✅ 아바타 적용: assistant는 HONGIK_AVATAR, user는 USER_AVATAR
    if role == "assistant":
        chat_ctx = st.chat_message("assistant", avatar=HONGIK_AVATAR)
    elif role == "user":
        chat_ctx = st.chat_message("user", avatar=USER_AVATAR)
    else:
        chat_ctx = st.chat_message(role)

    with chat_ctx:
        st.markdown(message["content"])

        # 어시스턴트 메시지에만 버튼 및 피드백 UI + 출처 표시
        if role == "assistant":
            # 신뢰도 표시 (현재는 similarity가 항상 None)
            similarity = message.get("similarity")
            if similarity is not None:
                display_confidence_badge(similarity)

            # 아직 피드백 모드가 없는 상태 (처음)
            if idx not in st.session_state.feedback_mode:
                # 왼쪽 여백, 👍, 👎, 복사, 오른쪽 여백
                spacer_l, col1, col2, col3, spacer_r = st.columns(
                    [0.1, 0.3, 0.3, 0.3, 4]
                )
                with col1:
                    if st.button("👍", key=f"like_{idx}"):
                        st.session_state.feedback_mode[idx] = {
                            "type": "satisfied",
                            "text": "",
                            "submitted": False
                        }
                        st.rerun()
                with col2:
                    if st.button("👎", key=f"dislike_{idx}"):
                        st.session_state.feedback_mode[idx] = {
                            "type": "unsatisfied",
                            "text": "",
                            "submitted": False
                        }
                        st.rerun()
                with col3:
                    render_copy_button(message["content"], idx)

            else:
                feedback_info = st.session_state.feedback_mode[idx]
                feedback_type = feedback_info["type"]

                # 제출 완료된 상태
                if feedback_info["submitted"]:
                    st.success("✅ 피드백이 저장되었습니다. 감사합니다! 🙏")
                    st.info(
                        f"**{'만족' if feedback_type == 'satisfied' else '불만족'}** 선택\n\n"
                        f"**의견:** {feedback_info['text'] if feedback_info['text'] else '(없음)'}"
                    )

                    spacer_l, col1, col2, col3, spacer_r = st.columns(
                        [0.1, 0.3, 0.3, 0.3, 5]
                    )
                    with col1:
                        if st.button("✏️ 수정", key=f"edit_{idx}"):
                            st.session_state.feedback_mode[idx]["submitted"] = False
                            st.rerun()
                    with col2:
                        if st.button("🗑️ 삭제", key=f"delete_{idx}"):
                            del st.session_state.feedback_mode[idx]
                            if idx in st.session_state.feedback_ids:
                                del st.session_state.feedback_ids[idx]
                            st.rerun()
                    with col3:
                        render_copy_button(message["content"], idx)

                # 피드백 작성 중(미제출) 상태
                else:
                    feedback_text = st.text_area(
                        f"{'만족하신 점' if feedback_type == 'satisfied' else '불만족하신 점'}을 자세히 알려주세요 (선택사항):",
                        value=feedback_info["text"],
                        key=f"feedback_text_{idx}",
                        height=100
                    )

                    spacer_l, col1, col2, col3, spacer_r = st.columns(
                        [0.1, 0.3, 0.3, 0.3, 5]
                    )
                    with col1:
                        if st.button("✅ 완료", key=f"submit_{idx}"):
                            feedback_data = {
                                "timestamp": datetime.now().isoformat(),
                                "question": st.session_state.messages[idx - 1]["content"] if idx > 0 else "",
                                "answer": message["content"],
                                "feedback_type": feedback_type,
                                "feedback_text": feedback_text
                            }

                            is_update = idx in st.session_state.feedback_ids
                            feedback_id = st.session_state.feedback_ids.get(idx)

                            if is_update:
                                save_feedback(
                                    feedback_data,
                                    is_update=True,
                                    feedback_id=feedback_id
                                )
                            else:
                                save_feedback(feedback_data, is_update=False)
                                st.session_state.feedback_ids[idx] = feedback_data.get(
                                    "feedback_id"
                                )

                            st.session_state.feedback_mode[idx]["text"] = feedback_text
                            st.session_state.feedback_mode[idx]["submitted"] = True
                            st.rerun()
                    with col2:
                        if st.button("❌ 취소", key=f"cancel_{idx}"):
                            del st.session_state.feedback_mode[idx]
                            st.rerun()
                    with col3:
                        render_copy_button(message["content"], idx)

            # ✅ 여기서 출처 박스 렌더링 (항상 버튼 아래)
            sources = message.get("sources", [])
            render_sources_box(sources)

# 사용자 입력
if prompt := st.chat_input("질문을 입력하세요..."):
    # ✅ user 메시지도 아바타 적용
    with st.chat_message("user", avatar=USER_AVATAR):
        st.markdown(prompt)

    # ✅ 새 assistant 응답도 로고 아이콘 사용
    with st.chat_message("assistant", avatar=HONGIK_AVATAR):
        with st.spinner("답변을 생성하고 있습니다... (현재는 예시 응답만 표시됩니다)"):
            process_question(prompt)

    st.rerun()

# 푸터
st.markdown("---")
st.markdown(
    "<div style='text-align: center; color: gray; font-size: 0.8em;'>"
    "홍익대 QnA 챗봇 (프론트 전용) | UI/UX & 피드백 시스템만 포함됨"
    "</div>",
    unsafe_allow_html=True
)
